import 'vite/client';

declare module '*.png';
declare module '*.webp';
