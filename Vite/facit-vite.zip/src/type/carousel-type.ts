export type TCarouselRounded = 0 | 1 | 2 | 3;
