export type TModalFullScreen = 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | boolean;

export type TModalSize = 'sm' | 'lg' | 'xl' | null;
